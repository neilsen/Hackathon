package consumerphysics.com.myscioapplication.utils;

/**
 * Created by nadavg on 19/07/2016.
 */
public class StringUtils {
    public static boolean isEmpty(final String str) {
        return str == null || str.equals("");
    }
}
