// Root angle detector
// Copyright 2015 Jim Watson
//
// This version is written in C++ for performance.

#include <algorithm>
#include <vector>
#include <map>
#include <time.h>
#include <limits>
#include <cmath>
#include <fstream>
#include <valarray>

#include <wx/wxprec.h>
#ifndef WX_PRECOMP
    #include <wx/wx.h>
#endif
#include <wx/gbsizer.h>
#include <wx/filename.h>
#include <wx/dir.h>
#include <wx/listctrl.h>

#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/features2d/features2d.hpp>

using namespace cv;
using namespace std;


string help_str = 
"QAAFI Root Angle Detector\n"
"Written in 2015 by Jim Watson\n\n"
"Step 1: Select the folder containing the images to process by clicking the source folder's \"Browse\" button.\n\n"
"Step 2 (optional): Change the default location of the output .csv file.\n\n"
"Step 3: Use the \"<\" and \">\" buttons to navigate through the files in the source folder. "
"When an image is displayed, the root angle is automatically detected.\n\n"
"Step 4 (optional): Manually specify the roots to measure by left-clicking on the displayed image "
"3 times. The first click sets the planting location, the second click defines the line of the first "
"root, and the third click defines the line of the second root.\n\n"
"The .csv file is updated on each angle detection and on each manual update.\n\n"
"Changing the source folder clears any manually set angles.";


// setup
int focus_area_width = 200;  // area size where angles are detected
int focus_area_height = 120;
wxSize min_win_size = wxSize(724, 700);
const wxString default_out_filename = "angles.csv";
const wxString image_filespec = "*.bmp";  // if change this, update wxImage::AddHandler() call below
#ifdef __WXMSW__
	const wxString sep = "\\";
#else
	const wxString sep = "/";
#endif

struct img_line
{
	int start_x = 0;
	int start_y = 0;
	int stop_x = 0;
	int stop_y = 0;
};

struct img_features
{
	int focus_x = 0;  // top-left of focus area
	int focus_y = 0;
	vector<img_line> lines;  // all detected lines
	map<string, img_line> outer_lines;  // ["left"] || ["right"]
	double angle = 0.0;  // angle between outer lines
	bool features_detected = false;  // true only if features detected successfully
};

enum
{
	ID_Help_Button = 200,
	ID_Back_Button,
	ID_Forward_Button,
	ID_Src_Folder_Button,
	ID_Output_File_Button,

	override_none,   // user was not overriding
	override_p_loc,  // user just overrode the planting location
	override_r1,     // user just overrode the first root
};


// forward declarations
static int SortFilenames(const wxString& first, const wxString& second);
class SourceBitmap;


// main app class
class RAngle : public wxApp
{
    public:
        bool OnInit();
};


// The main Window of the GUI
class MainFrame : public wxFrame
{
    public:
        MainFrame();
		~MainFrame();
		void OnResize(wxSizeEvent& event);
        void OnHelpButton(wxCommandEvent& WXUNUSED(event));
		void OnBackButton(wxCommandEvent& WXUNUSED(event));
		void OnForwardButton(wxCommandEvent& WXUNUSED(event));
		void OnSrcButton(wxCommandEvent& WXUNUSED(event));
		void OnOutButton(wxCommandEvent& WXUNUSED(event));
		void InitData();
		void UpdateImage(int image_index);
		img_features GetFeatures(string image_filename);
		double GetAngle(img_line line_0, img_line line_1);
		wxImage DrawFeatures(img_features features, wxImage img);

		wxImage img;
		wxGauge* progress_bar = NULL;
		map<int, img_features> feature_overrides;  // <image_index, features>

    private:
		wxTextCtrl* src_text = NULL;
		wxTextCtrl* out_text = NULL;
		wxButton* out_button = NULL;
		wxButton* back_button = NULL;
		wxButton* forward_button = NULL;
		wxArrayString input_filenames;
		wxPanel* src_panel = NULL;
		SourceBitmap* src_bitmap = NULL;
		wxListCtrl* output_view = NULL;

        DECLARE_EVENT_TABLE()
};


// panel to display images and process mouse events
class SourceBitmap : public wxStaticBitmap
{
public:
	SourceBitmap(wxWindow* parent, MainFrame* main_frame);
	~SourceBitmap();
	void OnMouse(wxMouseEvent& event);

	int state = override_none;  // can be override_none, override_p_loc, override_r1

private:
	MainFrame *main_frame = NULL;

	DECLARE_EVENT_TABLE()
};


IMPLEMENT_APP(RAngle)

BEGIN_EVENT_TABLE(MainFrame, wxFrame)
	EVT_BUTTON(ID_Back_Button, MainFrame::OnBackButton)
	EVT_BUTTON(ID_Forward_Button, MainFrame::OnForwardButton)
	EVT_BUTTON(ID_Help_Button, MainFrame::OnHelpButton)
	EVT_BUTTON(ID_Src_Folder_Button, MainFrame::OnSrcButton)
	EVT_BUTTON(ID_Output_File_Button, MainFrame::OnOutButton)
	EVT_SIZE(MainFrame::OnResize)
END_EVENT_TABLE()

BEGIN_EVENT_TABLE(SourceBitmap, wxStaticBitmap)
	EVT_LEFT_DOWN(SourceBitmap::OnMouse)
END_EVENT_TABLE()


bool RAngle::OnInit()
{
    MainFrame* frame = new MainFrame();
    SetTopWindow(frame);
    frame->Show(true);

    return true;
}


// initialization of main window
MainFrame::MainFrame() : wxFrame(NULL, wxID_ANY, wxT("Jim's root angle detector"), wxPoint(50,50),
                                 min_win_size, wxDEFAULT_FRAME_STYLE)
{
	// buttons
	wxPanel* button_panel = new wxPanel(this);
	back_button = new wxButton(button_panel, ID_Back_Button, "<", wxDefaultPosition, wxSize(50, 40));
	forward_button = new wxButton(button_panel, ID_Forward_Button, ">", wxDefaultPosition, wxSize(50, 40));

	back_button->Enable(false);
	forward_button->Enable(false);

	wxBoxSizer* button_sizer = new wxBoxSizer(wxHORIZONTAL);
	button_sizer->Add(back_button, 1, (wxALL | wxEXPAND), 2);
	button_sizer->Add(forward_button, 1, (wxALL | wxEXPAND), 2);
	button_panel->SetSizer(button_sizer);

	// progress bar
	wxPanel* progress_panel = new wxPanel(this);
	progress_bar = new wxGauge(progress_panel, -1, 100);
	wxBoxSizer* progress_sizer = new wxBoxSizer(wxHORIZONTAL);
	progress_sizer->Add(progress_bar, 1, (wxALL | wxEXPAND), 2);
	progress_panel->SetSizer(progress_sizer);

	// file locations
	wxPanel* io_panel = new wxPanel(this);
	wxStaticText* src_label = new wxStaticText(io_panel, -1, "Source folder:");
	src_text = new wxTextCtrl(io_panel, -1, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxTE_READONLY);
	wxButton* src_button = new wxButton(io_panel, ID_Src_Folder_Button, "Browse...");
	wxStaticText* out_label = new wxStaticText(io_panel, -1, "Output file:");
	out_text = new wxTextCtrl(io_panel, -1, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxTE_READONLY);
	out_button = new wxButton(io_panel, ID_Output_File_Button, "Browse...");
	wxButton* help_button = new wxButton(io_panel, ID_Help_Button, "Help", wxDefaultPosition, wxSize(107, 50));
	out_button->Enable(false);

	wxGridBagSizer* io_grid_sizer = new wxGridBagSizer(5, 5);
	io_grid_sizer->SetEmptyCellSize(wxSize(120, 10));
	io_grid_sizer->Add(src_label, wxGBPosition(0, 0), wxDefaultSpan, (wxALIGN_RIGHT | wxALIGN_CENTER_VERTICAL | wxLEFT));
	io_grid_sizer->Add(src_text, wxGBPosition(0, 1), wxGBSpan(1, 4), (wxALL | wxEXPAND));
	io_grid_sizer->Add(src_button, wxGBPosition(0, 5));
	io_grid_sizer->Add(out_label, wxGBPosition(1, 0), wxDefaultSpan, (wxALIGN_RIGHT | wxALIGN_CENTER_VERTICAL | wxLEFT));
	io_grid_sizer->Add(out_text, wxGBPosition(1, 1), wxGBSpan(1, 4), (wxALL | wxEXPAND));
	io_grid_sizer->Add(out_button, wxGBPosition(1, 5));
	io_grid_sizer->Add(help_button, wxGBPosition(0, 6), wxGBSpan(2, 1), (wxALL | wxEXPAND));
	io_grid_sizer->AddGrowableCol(1, 1);
	io_grid_sizer->AddGrowableCol(6, 1);

	wxStaticBoxSizer* io_sizer = new wxStaticBoxSizer(new wxStaticBox(io_panel, -1, "File Locations"), wxHORIZONTAL);
	io_sizer->Add(io_grid_sizer, 1, (wxALL | wxEXPAND), 10);
	io_panel->SetSizer(io_sizer);

	// source image
	src_panel = new wxPanel(this);
	src_bitmap = new SourceBitmap(src_panel, this);
	wxStaticBoxSizer* src_sizer = new wxStaticBoxSizer(new wxStaticBox(src_panel, -1, "Source Image"), wxHORIZONTAL);
	src_sizer->Add(src_bitmap, 1, (wxALL | wxEXPAND), 2);
	src_panel->SetSizer(src_sizer);

	// output panel
	wxPanel* out_panel = new wxPanel(this);
	output_view = new wxListCtrl(out_panel, -1, wxDefaultPosition, wxDefaultSize, wxLC_REPORT);
	output_view->InsertColumn(0, "Filename", wxLIST_FORMAT_LEFT, wxLIST_AUTOSIZE_USEHEADER);
	output_view->InsertColumn(1, "Root Angle", wxLIST_FORMAT_LEFT, wxLIST_AUTOSIZE_USEHEADER);
	wxStaticBoxSizer* out_sizer = new wxStaticBoxSizer(new wxStaticBox(out_panel, -1, "Measurements"), wxHORIZONTAL);
	out_sizer->Add(output_view, 1, (wxALL|wxEXPAND), 2);
	out_panel->SetSizer(out_sizer);

	// main layout
	wxBoxSizer* src_out_sizer = new wxBoxSizer(wxHORIZONTAL);
	src_out_sizer->Add(src_panel, 2, (wxALL | wxEXPAND), 5);
	src_out_sizer->Add(out_panel, 1, (wxALL | wxEXPAND), 5);

	wxBoxSizer* sizer = new wxBoxSizer(wxVERTICAL);
	sizer->Add(io_panel, 0, (wxALL | wxEXPAND), 5);
	sizer->Add(src_out_sizer, 1, (wxALL | wxEXPAND));
	sizer->Add(progress_panel, 0, (wxLEFT | wxRIGHT | wxEXPAND), 5);
	sizer->Add(button_panel, 0, (wxLEFT | wxRIGHT | wxBOTTOM | wxEXPAND), 5);
	this->SetSizer(sizer);

	// keep colours consistent between panels (on Windows), and give frame a minimum size
	this->SetBackgroundColour(src_panel->GetBackgroundColour());
	this->SetMinSize(min_win_size);

	// enable jpeg support
	wxImage::AddHandler(new wxJPEGHandler());
}


MainFrame::~MainFrame()
{
}


void SourceBitmap::OnMouse(wxMouseEvent& event)
{
	if (!main_frame->img.IsOk())
		return;

	// convert mouse coordinates to image coordinates
	int bitmap_width, bitmap_height;
	this->GetClientSize(&bitmap_width, &bitmap_height);
	double width_fraction = (double)event.GetX() / bitmap_width;
	double height_fraction = (double)event.GetY() / bitmap_height;
	int img_x = (int)(width_fraction * main_frame->img.GetWidth());
	int img_y = (int)(height_fraction * main_frame->img.GetHeight());

	int image_index = main_frame->progress_bar->GetValue();
	img_features features;
	img_line line;
	switch (state)
	{
		case override_none:
			features.angle = 0;
			features.focus_x = img_x - (focus_area_width / 2);
			features.focus_y = img_y;
			main_frame->feature_overrides[image_index] = features;
			state = override_p_loc;
			main_frame->UpdateImage(image_index);
			break;

		case override_p_loc:
			features = main_frame->feature_overrides[image_index];
			line.start_x = features.focus_x + (focus_area_width / 2);
			line.start_y = features.focus_y;
			line.stop_x = img_x;
			line.stop_y = img_y;
			features.outer_lines["left"] = line;
			main_frame->feature_overrides[image_index] = features;
			state = override_r1;
			main_frame->UpdateImage(image_index);
			break;

		case override_r1:
			features = main_frame->feature_overrides[image_index];
			line.start_x = features.focus_x + (focus_area_width / 2);
			line.start_y = features.focus_y;
			line.stop_x = img_x;
			line.stop_y = img_y;
			features.outer_lines["right"] = line;
			if (features.outer_lines["left"].stop_x > features.outer_lines["right"].stop_x)
				swap(features.outer_lines["left"], features.outer_lines["right"]);
			features.angle = main_frame->GetAngle(features.outer_lines["left"], features.outer_lines["right"]);
			main_frame->feature_overrides[image_index] = features;
			state = override_none;
			main_frame->UpdateImage(image_index);
			break;

		default:
			break;
	}
}


void MainFrame::OnHelpButton(wxCommandEvent& WXUNUSED(event))
{
	wxMessageBox(help_str, wxT("Help"), (wxOK | wxICON_INFORMATION), this);
}


void MainFrame::OnBackButton(wxCommandEvent& WXUNUSED(event))
{
	int next_image_index = progress_bar->GetValue() - 1;

	progress_bar->SetValue(next_image_index);
	UpdateImage(next_image_index);
	forward_button->Enable(true);

	if (next_image_index == 0)  // this is the first image available
		back_button->Enable(false);
}


void MainFrame::OnForwardButton(wxCommandEvent& WXUNUSED(event))
{
	src_bitmap->state = override_none;
	int next_image_index = progress_bar->GetValue() + 1;

	progress_bar->SetValue(next_image_index);
	UpdateImage(next_image_index);
	back_button->Enable(true);

	if (next_image_index == (int)input_filenames.GetCount() - 1)  // this is the last image available
		forward_button->Enable(false);
}


void MainFrame::OnSrcButton(wxCommandEvent& WXUNUSED(event))
{
	wxDirDialog* dir_dialog = new wxDirDialog(this, "Select image folder...", "", (wxDD_DEFAULT_STYLE | wxDD_DIR_MUST_EXIST | wxDD_CHANGE_DIR));
	if (dir_dialog->ShowModal() == wxID_OK)
	{
		feature_overrides.clear();

		wxString src_folder_text = dir_dialog->GetPath();
		src_text->SetValue(src_folder_text);
		wxString out_filename_text = src_folder_text + sep + default_out_filename;
		out_text->SetValue(out_filename_text);
		out_button->Enable(true);

		// check if the output filename is valid
		wxFileName out_filename = wxFileName(out_filename_text);
		if (!out_filename.IsOk())
		{
			wxMessageBox("Output filename invalid", "Error", (wxOK | wxICON_ERROR), this);
			out_text->SetValue("");
		}

		// check if output filename already exists
		if (out_filename.FileExists())
		{
			if (wxMessageBox("Overwrite existing output file?", "Output file already exists",
				(wxYES_NO | wxICON_QUESTION), this) != wxYES)
			{
				out_text->SetValue("");
			}
		}

		if ((src_text->GetValue() != "") && (out_text->GetValue() != ""))
			InitData();
	}

	dir_dialog->Destroy();
}


void MainFrame::OnOutButton(wxCommandEvent& WXUNUSED(event))
{
	wxFileDialog* file_dialog = new wxFileDialog(this, "Select output filename...", "", "angles.csv",
		"Comma separated value files (*.csv)|*.csv|All files (*.*)|*.*", (wxFD_SAVE | wxFD_OVERWRITE_PROMPT));
	
	if (file_dialog->ShowModal() == wxID_OK)
	{
		out_text->SetValue(file_dialog->GetPath());
		InitData();
	}

	file_dialog->Destroy();
}


// initializes the GUI using the values in src_text and out_text
void MainFrame::InitData()
{
	// disable navigation buttons until input is verified
	back_button->Enable(false);
	forward_button->Enable(false);

	// clear any existing input files
	input_filenames.Clear();
	output_view->DeleteAllItems();

	// make sure output filename is OK
	wxFileName out_filename = wxFileName(out_text->GetValue());
	if (!out_filename.IsOk())
	{
		wxMessageBox("Output filename is invalid.", "Error", (wxOK | wxICON_ERROR), this);
		return;
	}

	// check source directory provided is OK
	if (!wxFileName::DirExists(src_text->GetValue()))
	{
		wxMessageBox("Source directory does not exist.", "Error", (wxOK | wxICON_ERROR), this);
		return;
	}

	// load the filenames to process
	wxDir::GetAllFiles(src_text->GetValue(), &input_filenames, image_filespec, wxDIR_FILES);
	input_filenames.Sort(SortFilenames);
	if (input_filenames.GetCount() == 0)
	{
		wxMessageBox("No image files were found in the source folder.", "No image files", (wxOK | wxICON_INFORMATION), this);
		return;
	}

	// initialize progress bar and output views
	progress_bar->SetRange(input_filenames.GetCount() - 1);
	progress_bar->SetValue(0);  // progress_bar keeps track of image index
	for (unsigned int i = 0; i < input_filenames.GetCount(); i++)
	{
		wxString path, name, ext;
		wxFileName::SplitPath(input_filenames.Item(i), &path, &name, &ext);
		output_view->InsertItem(i, (name + "." + ext));
	}

	UpdateImage(0);  // load first image in sorted list of filenames

	forward_button->Enable(true);
}


void MainFrame::UpdateImage(int image_index)
{
	// load image and detect features
	string std_filename = std::string(input_filenames.Item(image_index));
	img_features features;
	if (feature_overrides.count(image_index) == 0)
		features = GetFeatures(std_filename);
	else
		features = feature_overrides[image_index];
	img = DrawFeatures(features, wxImage(input_filenames.Item(image_index)));

	// update angle display and save csv file
	output_view->SetItem(image_index, 1, wxString::Format("%.2f", features.angle));
	ofstream data_file(out_text->GetValue());
	if (data_file.is_open())
	{
		data_file << "Filename, Root Angle" << endl;
		for (int i = 0; i < output_view->GetItemCount(); i++)
		{
			wxListItem item;
			item.SetId(i);
			item.SetMask(wxLIST_MASK_TEXT);

			// filename
			item.SetColumn(0);
			output_view->GetItem(item);
			data_file << item.GetText() << ", ";

			// angle
			item.SetColumn(1);
			output_view->GetItem(item);
			data_file << item.GetText() << endl;
		}
		data_file.close();
	}
	else
		wxMessageBox(("Unable to save to output file: " + out_text->GetValue()), "Error", (wxOK | wxICON_ERROR));

	// scale the image for bitmap display
	int display_w, display_h, resized_w, resized_h;
	int src_w = img.GetWidth();
	int src_h = img.GetHeight();
	src_bitmap->GetClientSize(&display_w, &display_h);
	if (src_w > src_h)
	{
		resized_w = display_w;
		resized_h = ((float)resized_w / src_w) * src_h;
	}
	else
	{
		resized_h = display_h;
		resized_w = ((float)resized_h / src_h) * src_w;
	}

	wxImage resized_image = img.Scale(resized_w, resized_h, wxIMAGE_QUALITY_HIGH);
	src_bitmap->SetBitmap(resized_image);
	src_panel->Refresh();
}


void MainFrame::OnResize(wxSizeEvent& event)
{
	if (input_filenames.GetCount() > 0)
		UpdateImage(progress_bar->GetValue());

	event.Skip();  // sizer layout relies on this event
}


img_features MainFrame::GetFeatures(string image_filename)
{
	img_features features;
	features.features_detected = false;

	// open file
	Mat src_img;
	src_img = imread(image_filename, CV_LOAD_IMAGE_COLOR);
	if (src_img.empty())
	{
		wxMessageBox(("Could not open file " + image_filename), "Error loading file", (wxOK | wxICON_ERROR), this);
		return features;
	}

	// get mask for planting locations
	Mat hue_img, p_loc_mask, lower_red_hue_range, upper_red_hue_range;  // red has a hue between 0 -> 10, and 160 -> 180
	cvtColor(src_img, hue_img, CV_BGR2HSV);  // hue goes from 0 -> 179, S and V are 0 -> 255
	inRange(hue_img, Scalar(0, 150, 150), Scalar(10, 255, 255), lower_red_hue_range);  // set saturation and value high
	inRange(hue_img, Scalar(160, 150, 150), Scalar(180, 255, 255), upper_red_hue_range);
	addWeighted(lower_red_hue_range, 1.0, upper_red_hue_range, 1.0, 0.0, p_loc_mask);

	// apply planting location mask to black and white version of source image
	Mat grey_img, p_loc_img, p_loc_bw_img;
	cvtColor(src_img, grey_img, CV_BGR2GRAY);
	bitwise_and(grey_img, grey_img, p_loc_img, p_loc_mask);
	threshold(p_loc_img, p_loc_bw_img, 10, 255, THRESH_BINARY);  // set all values above 10 to 255

	// detect planting locations
	SimpleBlobDetector::Params params;
	params.filterByConvexity = false;
	params.blobColor = 255;
	SimpleBlobDetector detector(params);
	vector<KeyPoint> keypoints;
	detector.detect(p_loc_bw_img, keypoints);

	// find central planting location
	vector<float> x_values;  // index same as keypoints
	x_values.reserve(keypoints.size());
	for (unsigned int i = 0; i < keypoints.size(); i++)
		x_values.push_back(keypoints[i].pt.x);
	float left_x = *(min_element(x_values.begin(), x_values.end()));
	float right_x = *(max_element(x_values.begin(), x_values.end()));
	float mid_x = left_x + ((right_x - left_x) / 2);
	float min_dist = (float)numeric_limits<int>::max();  // initialize to large number
	int mid_k = 0;  // index to middle keypoint
	for (unsigned int i = 0; i < keypoints.size(); i++)
	{
		float this_x = keypoints[i].pt.x;
		float this_dist = std::abs(this_x - mid_x);
		if (this_dist < min_dist)
		{
			mid_k = i;
			min_dist = this_dist;
		}
	}

	// get focus area
	features.focus_x = (int)keypoints[mid_k].pt.x - (focus_area_width / 2);
	features.focus_y = (int)keypoints[mid_k].pt.y;
	Rect focus_area(features.focus_x, features.focus_y, focus_area_width, focus_area_height);

	// detect lines in focus area
	Mat focus_image = grey_img(focus_area);
	Mat edges;
	Canny(focus_image, edges, 40, 140, 3, true);
	vector<Vec4i> lines;
	HoughLinesP(edges, lines, 1, (CV_PI / 180), 20, 40, 10);

	// classify the lines
	int low_x = numeric_limits<int>::max();  // initialize to large number
	int high_x = numeric_limits<int>::min();  // initialize to small number
	for (unsigned int i = 0; i < lines.size(); i++)
	{
		img_line l;
		l.start_x = lines[i][0] + features.focus_x;
		l.start_y = lines[i][1] + features.focus_y;
		l.stop_x = lines[i][2] + features.focus_x;
		l.stop_y = lines[i][3] + features.focus_y;

		features.lines.push_back(l);

		int l_left_x = min(l.start_x, l.stop_x);
		int l_right_x = max(l.start_x, l.stop_x);
		if (l_left_x < low_x)
		{
			features.outer_lines["left"] = l;
			low_x = l_left_x;
		}
		if (l_right_x > high_x)
		{
			features.outer_lines["right"] = l;
			high_x = l_right_x;
		}
	}

	// get the angle between the outer lines
	if (features.outer_lines.size() == 2)  // else leave features.features_detected as false
	{
		features.angle = GetAngle(features.outer_lines["left"], features.outer_lines["right"]);
		features.features_detected = true;
	}

	return features;
}


// gets the angle between the two given lines
double MainFrame::GetAngle(img_line line_0, img_line line_1)
{
	// make sure start of the lines are above (to get angle below junction)
	if (line_0.start_y > line_0.stop_y)
	{
		swap(line_0.start_x, line_0.stop_x);
		swap(line_0.start_y, line_0.stop_y);
	}
	if (line_1.start_y > line_1.stop_y)
	{
		swap(line_1.start_x, line_1.stop_x);
		swap(line_1.start_y, line_1.stop_y);
	}

	// get unit vectors
	valarray<double> v0({(double)(line_0.stop_x - line_0.start_x), (double)(line_0.stop_y - line_0.start_y)});
	valarray<double> v1({(double)(line_1.stop_x - line_1.start_x), (double)(line_1.stop_y - line_1.start_y)});
	valarray<double> unit0 = v0 / sqrt((v0 * v0).sum());
	valarray<double> unit1 = v1 / sqrt((v1 * v1).sum());

	// get angle
	double angle_radians = acos((unit0 * unit1).sum());
	double angle_degrees = angle_radians * (360 / (2 * CV_PI));

	return angle_degrees;
}


// sorts filenames according to their numeric value (else "10" < "2")
static int SortFilenames(const wxString& first, const wxString& second)
{
	long first_num, second_num;
	wxString path, name, ext;

	wxFileName::SplitPath(first, &path, &name, &ext);
	if (!name.ToLong(&first_num))  // name is not an integer string
		return 0;  // declare the filenames equal

	wxFileName::SplitPath(second, &path, &name, &ext);
	if (!name.ToLong(&second_num))  // not an integer string
		return 0;

	return (first_num - second_num);
}


wxImage MainFrame::DrawFeatures(img_features features, wxImage src_img)
{
	wxBitmap bitmap(src_img);
	wxMemoryDC dc(bitmap);
	dc.SetBrush(*wxTRANSPARENT_BRUSH);

	// planting location
	int p_loc_x = features.focus_x + (focus_area_width / 2);
	int p_loc_y = features.focus_y;
	dc.SetPen(wxPen(wxColor("yellow"), 3));
	dc.DrawCircle(p_loc_x, p_loc_y, 20);

	// focus area
	dc.SetPen(wxPen(wxColour("green"), 7));
	dc.DrawRectangle(features.focus_x, features.focus_y, focus_area_width, focus_area_height);

	// outer lines
	dc.SetPen(wxPen(wxColour("red"), 7));
	for (const auto &l : features.outer_lines)
		dc.DrawLine(l.second.start_x, l.second.start_y, l.second.stop_x, l.second.stop_y);

	// angle value
	dc.SetTextForeground(wxColour("black"));
	dc.SetFont(wxFont(40, wxFONTFAMILY_SWISS, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_NORMAL));
	dc.DrawText(wxString::Format("%.2f", features.angle), (p_loc_x - 45), (p_loc_y - 120));

	dc.SelectObject(wxNullBitmap);
	return bitmap.ConvertToImage();
}


SourceBitmap::SourceBitmap(wxWindow* parent, MainFrame* main_frame) : wxStaticBitmap(parent, -1, wxNullBitmap)
{
	this->main_frame = main_frame;
}


SourceBitmap::~SourceBitmap()
{
}
